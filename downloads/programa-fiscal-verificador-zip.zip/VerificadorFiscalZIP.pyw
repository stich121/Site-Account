from fiscal_zip_checker import main


main()
