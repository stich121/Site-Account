#!/usr/bin/env python3
"""Check invoice XML files inside a ZIP and export a tax summary to Excel."""

from __future__ import annotations

import argparse
import html
import re
import sys
import zipfile
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from tkinter import Tk, StringVar, filedialog, messagebox, ttk
from xml.etree import ElementTree as ET


TAX_FIELDS = {
    "ICMS": ("vICMS", "vICMSST", "vST", "vFCP", "vFCPST", "vFCPUFDest"),
    "IPI": ("vIPI",),
    "PIS": ("vPIS", "vPis"),
    "COFINS": ("vCOFINS", "vCofins"),
    "ISS": ("vISS", "ValorIss", "ValorISS", "BaseCalculo", "ValorIssRetido"),
    "IRRF": ("vIRRF", "vRetIRRF", "ValorIr", "ValorIRRF"),
    "INSS": ("vRetPrevid", "ValorInss", "ValorINSS"),
    "CSLL": ("vRetCSLL", "ValorCsll", "ValorCSLL"),
}

TAX_NAMES = tuple(TAX_FIELDS)


@dataclass
class InvoiceResult:
    file_name: str
    model: str
    number: str
    issue_date: str
    issuer_cnpj: str
    issuer_name: str
    recipient_cnpj: str
    total_invoice: Decimal
    tax_values: dict[str, Decimal]
    total_tax: Decimal
    status: str
    alerts: str


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def clean_xml_text(value: object) -> str:
    text = "" if value is None else str(value)
    text = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", text)
    return html.escape(text, quote=True)


def decimal_from_text(text: str | None) -> Decimal:
    if not text:
        return Decimal("0")
    normalized = text.strip().replace(".", "").replace(",", ".") if "," in text else text.strip()
    try:
        return Decimal(normalized)
    except InvalidOperation:
        return Decimal("0")


def first_child_text(parent: ET.Element | None, *names: str) -> str:
    if parent is None:
        return ""
    for name in names:
        for child in parent.iter():
            if local_name(child.tag) == name and child.text:
                return child.text.strip()
    return ""


def first_direct_child(parent: ET.Element | None, name: str) -> ET.Element | None:
    if parent is None:
        return None
    for child in parent:
        if local_name(child.tag) == name:
            return child
    return None


def find_first(root: ET.Element, *names: str) -> ET.Element | None:
    wanted = set(names)
    for item in root.iter():
        if local_name(item.tag) in wanted:
            return item
    return None


def find_first_text(root: ET.Element, *names: str) -> str:
    for name in names:
        for item in root.iter():
            if local_name(item.tag) == name and item.text:
                return item.text.strip()
    return ""


def first_available_text(*values: str) -> str:
    for value in values:
        if value:
            return value
    return ""


def collect_tax_values(root: ET.Element) -> dict[str, Decimal]:
    values = {tax: Decimal("0") for tax in TAX_NAMES}
    tax_tags: dict[str, str] = {}
    for tax, tags in TAX_FIELDS.items():
        for tag in tags:
            tax_tags[tag] = tax

    total_node = find_first(root, "ICMSTot")
    search_root = total_node if total_node is not None else root

    for item in search_root.iter():
        tax = tax_tags.get(local_name(item.tag))
        if tax and item.text:
            values[tax] += decimal_from_text(item.text)

    return values


def detect_model(root: ET.Element) -> str:
    model = first_child_text(find_first(root, "ide"), "mod")
    if model == "55":
        return "NF-e"
    if model == "65":
        return "NFC-e"
    if model == "57":
        return "CT-e"
    if find_first(root, "CompNfse", "Nfse", "NFSe", "InfNfse", "infNfse", "infNFSe", "DPS", "infDPS") is not None:
        return "NFS-e"
    return model or "XML"


def invoice_total(root: ET.Element) -> Decimal:
    total_node = find_first(root, "ICMSTot")
    if total_node is not None:
        return decimal_from_text(first_child_text(total_node, "vNF", "vTPrest"))
    service_value = find_first_text(root, "vServ", "ValorServicos")
    if service_value:
        return decimal_from_text(service_value)
    valores = find_first(root, "Valores", "valores")
    if valores is not None:
        return decimal_from_text(first_child_text(valores, "ValorLiquidoNfse", "vLiq"))
    return decimal_from_text(find_first_text(root, "vLiq", "ValorLiquidoNfse"))


def invoice_number(root: ET.Element, info: ET.Element | None) -> str:
    return first_available_text(
        first_child_text(info, "nNF", "nCT", "nNFSe", "nNFS-e", "Numero", "NumeroNfse", "NumeroNFS-e"),
        first_child_text(info, "nDPS", "NumeroDps", "NumeroDPS"),
        find_first_text(root, "nNFSe", "nNFS-e", "NumeroNfse", "NumeroNFS-e"),
        find_first_text(root, "nDPS", "NumeroDps", "NumeroDPS"),
    )


def invoice_issue_date(root: ET.Element, info: ET.Element | None) -> str:
    return first_available_text(
        first_child_text(
            info,
            "dhEmi",
            "dEmi",
            "DataEmissao",
            "DataEmissaoNfse",
            "DataEmissaoNFS-e",
            "dhProc",
            "dCompet",
        ),
        find_first_text(root, "dhEmi", "dEmi", "DataEmissao", "DataEmissaoNfse", "DataEmissaoNFS-e"),
        find_first_text(root, "dhProc", "dCompet"),
    )


def issuer_node(root: ET.Element) -> ET.Element | None:
    return find_first(root, "emit", "PrestadorServico", "prest", "Prestador", "infPrestador")


def recipient_node(root: ET.Element) -> ET.Element | None:
    return find_first(root, "dest", "TomadorServico", "toma", "Tomador", "infTomador")


def tax_id_from_node(node: ET.Element | None) -> str:
    return first_child_text(node, "CNPJ", "CPF", "CpfCnpj", "Cnpj", "Cpf")


def name_from_node(node: ET.Element | None) -> str:
    return first_child_text(node, "xNome", "RazaoSocial", "Nome", "xNomePrestador", "NomeFantasia")


def parse_invoice_xml(file_name: str, data: bytes) -> InvoiceResult:
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        return InvoiceResult(
            file_name=file_name,
            model="XML invalido",
            number="",
            issue_date="",
            issuer_cnpj="",
            issuer_name="",
            recipient_cnpj="",
            total_invoice=Decimal("0"),
            tax_values={tax: Decimal("0") for tax in TAX_NAMES},
            total_tax=Decimal("0"),
            status="Erro",
            alerts=f"XML invalido: {exc}",
        )

    ide = find_first(root, "ide", "IdentificacaoNfse", "infNFSe", "infNfse", "infDPS")
    emit = issuer_node(root)
    dest = recipient_node(root)
    inf_prot = find_first(root, "infProt")

    tax_values = collect_tax_values(root)
    total_tax = sum(tax_values.values(), Decimal("0"))
    status = "Com imposto" if total_tax > 0 else "Sem imposto destacado"

    alerts: list[str] = []
    if total_tax == 0:
        alerts.append("Nenhum imposto com valor maior que zero foi encontrado")
    if first_child_text(inf_prot, "cStat") in {"101", "135", "155"}:
        alerts.append("Nota aparenta estar cancelada no protocolo")

    return InvoiceResult(
        file_name=file_name,
        model=detect_model(root),
        number=invoice_number(root, ide),
        issue_date=invoice_issue_date(root, ide),
        issuer_cnpj=tax_id_from_node(emit),
        issuer_name=name_from_node(emit),
        recipient_cnpj=tax_id_from_node(dest),
        total_invoice=invoice_total(root),
        tax_values=tax_values,
        total_tax=total_tax,
        status=status,
        alerts="; ".join(alerts),
    )


def read_zip_invoices(zip_path: Path) -> list[InvoiceResult]:
    results: list[InvoiceResult] = []
    with zipfile.ZipFile(zip_path) as archive:
        for info in archive.infolist():
            if info.is_dir() or not info.filename.lower().endswith(".xml"):
                continue
            with archive.open(info) as xml_file:
                results.append(parse_invoice_xml(info.filename, xml_file.read()))
    return results


def column_name(index: int) -> str:
    name = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name


def cell_ref(row: int, column: int) -> str:
    return f"{column_name(column)}{row}"


def inline_cell(row: int, column: int, value: object, style: int = 0) -> str:
    style_attr = f' s="{style}"' if style else ""
    return (
        f'<c r="{cell_ref(row, column)}" t="inlineStr"{style_attr}>'
        f"<is><t>{clean_xml_text(value)}</t></is></c>"
    )


def number_cell(row: int, column: int, value: Decimal | int | float, style: int = 0) -> str:
    style_attr = f' s="{style}"' if style else ""
    return f'<c r="{cell_ref(row, column)}"{style_attr}><v>{value}</v></c>'


def row_xml(row_number: int, cells: list[str]) -> str:
    return f'<row r="{row_number}">{"".join(cells)}</row>'


def styles_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>
<fonts count="3">
<font><sz val="11"/><color theme="1"/><name val="Calibri"/></font>
<font><b/><sz val="15"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
</fonts>
<fills count="4">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF0F172A"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFEFF6FF"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFD9DEE3"/></left><right style="thin"><color rgb="FFD9DEE3"/></right><top style="thin"><color rgb="FFD9DEE3"/></top><bottom style="thin"><color rgb="FFD9DEE3"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="6">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def sheet_xml(rows: list[str], widths: list[float], auto_filter_ref: str) -> str:
    cols = "".join(
        f'<col min="{idx}" max="{idx}" width="{width}" customWidth="1"/>'
        for idx, width in enumerate(widths, start=1)
    )
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
<cols>{cols}</cols>
<sheetData>{''.join(rows)}</sheetData>
<autoFilter ref="{auto_filter_ref}"/>
</worksheet>"""


def workbook_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Conferencia Fiscal" sheetId="1" r:id="rId1"/></sheets>
</workbook>"""


def workbook_rels_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""


def root_rels_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""


def content_types_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""


def build_results_sheet(results: list[InvoiceResult]) -> str:
    headers = [
        "Arquivo",
        "Modelo",
        "Numero",
        "Emissao",
        "CNPJ emissor",
        "Emissor",
        "CNPJ destinatario",
        "Valor nota",
        *TAX_NAMES,
        "Total impostos",
        "Status",
        "Alertas",
    ]
    rows = [row_xml(1, [inline_cell(1, idx, header, 2) for idx, header in enumerate(headers, start=1)])]

    for row_number, result in enumerate(results, start=2):
        cells = [
            inline_cell(row_number, 1, result.file_name, 4),
            inline_cell(row_number, 2, result.model, 4),
            inline_cell(row_number, 3, result.number, 4),
            inline_cell(row_number, 4, result.issue_date, 4),
            inline_cell(row_number, 5, result.issuer_cnpj, 4),
            inline_cell(row_number, 6, result.issuer_name, 4),
            inline_cell(row_number, 7, result.recipient_cnpj, 4),
            number_cell(row_number, 8, result.total_invoice, 3),
        ]
        for offset, tax in enumerate(TAX_NAMES, start=9):
            cells.append(number_cell(row_number, offset, result.tax_values[tax], 3))
        status_style = 5 if result.total_tax == 0 or result.alerts else 4
        cells.extend(
            [
                number_cell(row_number, 9 + len(TAX_NAMES), result.total_tax, 3),
                inline_cell(row_number, 10 + len(TAX_NAMES), result.status, status_style),
                inline_cell(row_number, 11 + len(TAX_NAMES), result.alerts, status_style),
            ]
        )
        rows.append(row_xml(row_number, cells))

    if not results:
        rows.append(row_xml(2, [inline_cell(2, 1, "Nenhum XML encontrado dentro do ZIP.", 4)]))

    last_row = max(len(results) + 1, 2)
    last_col = column_name(len(headers))
    widths = [36, 12, 14, 22, 18, 34, 20, 14, 12, 12, 12, 12, 12, 12, 12, 12, 16, 22, 60]
    return sheet_xml(rows, widths, f"A1:{last_col}{last_row}")


def write_xlsx(results: list[InvoiceResult], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as workbook:
        workbook.writestr("[Content_Types].xml", content_types_xml())
        workbook.writestr("_rels/.rels", root_rels_xml())
        workbook.writestr("xl/workbook.xml", workbook_xml())
        workbook.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml())
        workbook.writestr("xl/styles.xml", styles_xml())
        workbook.writestr("xl/worksheets/sheet1.xml", build_results_sheet(results))


def check_zip_to_excel(zip_path: Path, output_path: Path) -> list[InvoiceResult]:
    results = read_zip_invoices(zip_path)
    write_xlsx(results, output_path)
    return results


class FiscalZipCheckerApp:
    def __init__(self) -> None:
        self.root = Tk()
        self.root.title("Verificador Fiscal de XML em ZIP")
        self.root.geometry("820x300")
        self.root.minsize(720, 280)

        self.input_var = StringVar()
        self.output_var = StringVar()
        self.status_var = StringVar(value="Escolha um ZIP com XMLs de notas e gere a conferencia em Excel.")

        self._build()

    def _build(self) -> None:
        frame = ttk.Frame(self.root, padding=18)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)

        ttk.Label(frame, text="Verificar impostos em XMLs de notas", font=("Segoe UI", 16, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 16)
        )

        ttk.Label(frame, text="Arquivo ZIP").grid(row=1, column=0, sticky="w", pady=6)
        ttk.Entry(frame, textvariable=self.input_var).grid(row=1, column=1, sticky="ew", padx=8, pady=6)
        ttk.Button(frame, text="Procurar...", command=self.choose_input).grid(row=1, column=2, pady=6)

        ttk.Label(frame, text="Salvar Excel em").grid(row=2, column=0, sticky="w", pady=6)
        ttk.Entry(frame, textvariable=self.output_var).grid(row=2, column=1, sticky="ew", padx=8, pady=6)
        ttk.Button(frame, text="Escolher...", command=self.choose_output).grid(row=2, column=2, pady=6)

        ttk.Button(frame, text="Verificar ZIP e gerar Excel", command=self.convert).grid(
            row=3, column=1, sticky="e", pady=(18, 8)
        )
        ttk.Label(frame, textvariable=self.status_var, foreground="#334155").grid(
            row=4, column=0, columnspan=3, sticky="w", pady=(12, 0)
        )

    def choose_input(self) -> None:
        path = filedialog.askopenfilename(
            title="Escolha o arquivo ZIP",
            filetypes=[("Arquivos ZIP", "*.zip *.ZIP"), ("Todos os arquivos", "*.*")],
        )
        if not path:
            return
        self.input_var.set(path)
        if not self.output_var.get():
            self.output_var.set(str(Path(path).with_name(f"{Path(path).stem}_conferencia_fiscal.xlsx")))

    def choose_output(self) -> None:
        initial = (
            Path(self.input_var.get()).with_name(f"{Path(self.input_var.get()).stem}_conferencia_fiscal.xlsx")
            if self.input_var.get()
            else Path("conferencia_fiscal.xlsx")
        )
        path = filedialog.asksaveasfilename(
            title="Salvar Excel como",
            initialfile=initial.name,
            defaultextension=".xlsx",
            filetypes=[("Planilha Excel", "*.xlsx")],
        )
        if path:
            self.output_var.set(path)

    def convert(self) -> None:
        input_path = Path(self.input_var.get().strip())
        output_path = Path(self.output_var.get().strip())
        if not input_path.exists() or input_path.suffix.lower() != ".zip":
            messagebox.showerror("Arquivo invalido", "Escolha um arquivo ZIP valido.")
            return
        if output_path.suffix.lower() != ".xlsx":
            output_path = output_path.with_suffix(".xlsx")
            self.output_var.set(str(output_path))

        try:
            results = check_zip_to_excel(input_path, output_path)
        except zipfile.BadZipFile:
            messagebox.showerror("ZIP invalido", "Nao foi possivel abrir o arquivo ZIP escolhido.")
            self.status_var.set("Nao foi possivel abrir o ZIP.")
            return
        except Exception as exc:  # pragma: no cover - GUI feedback path
            messagebox.showerror("Erro na verificacao", str(exc))
            self.status_var.set("Nao foi possivel verificar o ZIP.")
            return

        with_tax = sum(1 for item in results if item.total_tax > 0)
        without_tax = len(results) - with_tax
        self.status_var.set(
            f"Excel criado: {output_path} | XMLs: {len(results)} | com imposto: {with_tax} | sem imposto: {without_tax}"
        )
        messagebox.showinfo("Conferencia concluida", f"Excel criado com sucesso:\n{output_path}")

    def run(self) -> None:
        self.root.mainloop()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Verifica impostos em XMLs de notas dentro de um ZIP.")
    parser.add_argument("zip", nargs="?", type=Path, help="Arquivo .zip com XMLs de notas.")
    parser.add_argument("-o", "--output", type=Path, help="Arquivo .xlsx de saida.")
    args = parser.parse_args(argv)

    if args.zip is None:
        FiscalZipCheckerApp().run()
        return 0

    if not args.zip.exists():
        parser.error("arquivo ZIP nao encontrado")
    if args.zip.suffix.lower() != ".zip":
        parser.error("informe um arquivo .zip")

    output_path = args.output or args.zip.with_name(f"{args.zip.stem}_conferencia_fiscal.xlsx")
    if output_path.suffix.lower() != ".xlsx":
        output_path = output_path.with_suffix(".xlsx")

    results = check_zip_to_excel(args.zip, output_path)
    with_tax = sum(1 for item in results if item.total_tax > 0)
    without_tax = len(results) - with_tax
    print(f"Excel criado: {output_path}")
    print(f"XMLs: {len(results)} | com imposto: {with_tax} | sem imposto: {without_tax}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
