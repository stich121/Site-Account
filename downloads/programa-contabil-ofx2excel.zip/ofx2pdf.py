#!/usr/bin/env python3
"""Convert Brazilian OFX bank statements to PDF."""

from __future__ import annotations

import argparse
import html
import re
import sys
import unicodedata
from pathlib import Path

from ofx_parser import Statement, collect_inputs, money, parse_statement

try:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        BaseDocTemplate,
        Frame,
        KeepTogether,
        PageBreak,
        PageTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
    )
except ImportError as exc:  # pragma: no cover - exercised by users without deps
    raise SystemExit(
        "A biblioteca 'reportlab' nao esta instalada.\n"
        "Instale com: python -m pip install reportlab"
    ) from exc


def safe_text(value: object) -> str:
    text = str(value or "")
    text = unicodedata.normalize("NFC", text)
    return html.escape(text)


def on_page(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#555555"))
    canvas.drawRightString(doc.pagesize[0] - 1.2 * cm, 0.8 * cm, f"Pagina {doc.page}")
    canvas.restoreState()


def build_pdf(statement: Statement, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)

    page_size = landscape(A4)
    doc = BaseDocTemplate(
        str(output),
        pagesize=page_size,
        leftMargin=1.2 * cm,
        rightMargin=1.2 * cm,
        topMargin=1.0 * cm,
        bottomMargin=1.1 * cm,
        title=f"Extrato OFX - {statement.source.name}",
    )
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal")
    doc.addPageTemplates(PageTemplate(id="default", frames=[frame], onPage=on_page))

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="CenterSmall", fontSize=8, alignment=TA_CENTER, leading=10))
    styles.add(ParagraphStyle(name="RightSmall", fontSize=8, alignment=TA_RIGHT, leading=10))
    styles.add(ParagraphStyle(name="Cell", fontSize=7.2, leading=8.5))
    styles.add(ParagraphStyle(name="CellCenter", fontSize=7.2, leading=8.5, alignment=TA_CENTER))
    styles.add(ParagraphStyle(name="CellRight", fontSize=7.2, leading=8.5, alignment=TA_RIGHT))
    styles.add(
        ParagraphStyle(
            name="TitleClean",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=16,
            leading=20,
            spaceAfter=6,
        )
    )

    story = [
        Paragraph("Extrato bancario importado de OFX", styles["TitleClean"]),
        Paragraph(safe_text(statement.source.name), styles["Normal"]),
        Spacer(1, 0.25 * cm),
    ]

    account_rows = [
        ["Banco", statement.org or statement.bank_id or "-", "Codigo", statement.fid or statement.bank_id or "-"],
        ["Agencia", statement.branch_id or "-", "Conta", statement.account_id or "-"],
        ["Tipo", statement.account_type or "-", "Moeda", statement.currency],
        ["Periodo", f"{statement.start_date or '-'} a {statement.end_date or '-'}", "Lancamentos", str(len(statement.transactions))],
    ]
    account_table = Table(
        [[Paragraph(safe_text(cell), styles["Normal"]) for cell in row] for row in account_rows],
        colWidths=[2.2 * cm, 9.0 * cm, 2.2 * cm, 8.0 * cm],
    )
    account_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F4F6F8")),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#222222")),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D9DEE3")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    story.append(account_table)
    story.append(Spacer(1, 0.25 * cm))

    summary_rows = [
        ["Creditos", money(statement.credits, statement.currency)],
        ["Debitos", money(statement.debits, statement.currency)],
        ["Movimento liquido", money(statement.movement, statement.currency)],
        [
            f"Saldo OFX em {statement.ledger_date}" if statement.ledger_date else "Saldo OFX",
            money(statement.ledger_balance, statement.currency),
        ],
    ]
    summary_table = Table(
        [[Paragraph(safe_text(label), styles["Normal"]), Paragraph(safe_text(value), styles["RightSmall"])] for label, value in summary_rows],
        colWidths=[5.5 * cm, 5.0 * cm],
        hAlign="LEFT",
    )
    summary_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFFFFF")),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D9DEE3")),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    story.append(summary_table)
    story.append(Spacer(1, 0.35 * cm))

    tx_header = ["Data", "Tipo", "Documento", "Historico", "Valor"]
    tx_rows = [[Paragraph(safe_text(cell), styles["CellCenter"]) for cell in tx_header]]
    for tx in statement.transactions:
        document = tx.checknum or tx.refnum or tx.fitid
        tx_rows.append(
            [
                Paragraph(safe_text(tx.date), styles["CellCenter"]),
                Paragraph(safe_text(tx.type), styles["CellCenter"]),
                Paragraph(safe_text(document), styles["CellCenter"]),
                Paragraph(safe_text(tx.description), styles["Cell"]),
                Paragraph(safe_text(money(tx.amount, statement.currency)), styles["CellRight"]),
            ]
        )

    if len(tx_rows) == 1:
        tx_rows.append(
            [
                Paragraph("", styles["Cell"]),
                Paragraph("", styles["Cell"]),
                Paragraph("", styles["Cell"]),
                Paragraph("Nenhum lancamento encontrado no periodo.", styles["Cell"]),
                Paragraph("", styles["Cell"]),
            ]
        )

    tx_table = Table(tx_rows, colWidths=[2.2 * cm, 2.4 * cm, 3.3 * cm, 15.5 * cm, 3.2 * cm], repeatRows=1)
    tx_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#263238")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("ALIGN", (0, 0), (-1, 0), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D9DEE3")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFB")]),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    story.append(tx_table)
    doc.build(story)


def slug_part(value: str) -> str:
    value = unicodedata.normalize("NFKD", value)
    value = "".join(char for char in value if not unicodedata.combining(char))
    value = re.sub(r"[^A-Za-z0-9._ -]+", " ", value)
    return " ".join(value.split()).strip()


def unique_output_path(path: Path, used: set[Path]) -> Path:
    candidate = path
    counter = 2
    while candidate in used or candidate.exists():
        candidate = path.with_name(f"{path.stem} ({counter}){path.suffix}")
        counter += 1
    used.add(candidate)
    return candidate


def output_path_for(input_path: Path, output: Path | None, multiple: bool, used: set[Path]) -> Path:
    if output is None:
        return unique_output_path(input_path.with_suffix(".pdf"), used)
    if multiple or output.is_dir() or output.suffix.lower() != ".pdf":
        parent_hint = slug_part(input_path.parent.name)
        stem = slug_part(input_path.stem) or "extrato"
        filename = f"{stem} - {parent_hint}.pdf" if parent_hint else f"{stem}.pdf"
        return unique_output_path(output / filename, used)
    return unique_output_path(output, used)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Converte extratos OFX para PDF.")
    parser.add_argument("inputs", nargs="+", type=Path, help="Arquivo(s) OFX ou pasta(s) com OFX.")
    parser.add_argument("-o", "--output", type=Path, help="Arquivo PDF de saida ou pasta de destino.")
    args = parser.parse_args(argv)

    inputs = collect_inputs(args.inputs)
    if not inputs:
        parser.error("nenhum arquivo OFX encontrado")

    multiple = len(inputs) > 1
    used_outputs: set[Path] = set()
    for input_path in inputs:
        if not input_path.exists():
            print(f"Ignorando arquivo inexistente: {input_path}", file=sys.stderr)
            continue
        statement = parse_statement(input_path)
        output = output_path_for(input_path, args.output, multiple, used_outputs)
        build_pdf(statement, output)
        print(f"PDF criado: {output}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
