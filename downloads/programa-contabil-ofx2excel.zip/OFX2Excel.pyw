from ofx2excel import OfxExcelApp


if __name__ == "__main__":
    OfxExcelApp().run()
