#!/usr/bin/env python3
"""Convert OFX bank statements to Excel with an optional Tkinter interface."""

from __future__ import annotations

import argparse
import html
import re
import sys
import zipfile
from decimal import Decimal
from pathlib import Path
from tkinter import Tk, StringVar, filedialog, messagebox, ttk

from ofx_parser import Statement, collect_inputs, parse_statement


def xml_text(value: object) -> str:
    text = "" if value is None else str(value)
    text = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", text)
    return html.escape(text, quote=True)


def col_name(index: int) -> str:
    name = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name


def cell_ref(row: int, column: int) -> str:
    return f"{col_name(column)}{row}"


def inline_cell(row: int, column: int, value: object, style: int = 0) -> str:
    style_attr = f' s="{style}"' if style else ""
    return (
        f'<c r="{cell_ref(row, column)}" t="inlineStr"{style_attr}>'
        f"<is><t>{xml_text(value)}</t></is></c>"
    )


def number_cell(row: int, column: int, value: Decimal | int | float, style: int = 0) -> str:
    style_attr = f' s="{style}"' if style else ""
    return f'<c r="{cell_ref(row, column)}"{style_attr}><v>{value}</v></c>'


def row_xml(row_number: int, cells: list[str]) -> str:
    return f'<row r="{row_number}">{"".join(cells)}</row>'


def sheet_xml(rows: list[str], widths: list[float], auto_filter_ref: str | None = None) -> str:
    cols = "".join(
        f'<col min="{idx}" max="{idx}" width="{width}" customWidth="1"/>'
        for idx, width in enumerate(widths, start=1)
    )
    auto_filter = f'<autoFilter ref="{auto_filter_ref}"/>' if auto_filter_ref else ""
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
<cols>{cols}</cols>
<sheetData>{''.join(rows)}</sheetData>
{auto_filter}
</worksheet>"""


def workbook_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>
<sheet name="Lancamentos" sheetId="1" r:id="rId1"/>
</sheets>
</workbook>"""


def workbook_rels_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""


def root_rels_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""


def content_types_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""


def styles_xml() -> str:
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>
<fonts count="3">
<font><sz val="11"/><color theme="1"/><name val="Calibri"/></font>
<font><b/><sz val="14"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF263238"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFD9DEE3"/></left><right style="thin"><color rgb="FFD9DEE3"/></right><top style="thin"><color rgb="FFD9DEE3"/></top><bottom style="thin"><color rgb="FFD9DEE3"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="5">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def build_transactions_sheet(statement: Statement) -> str:
    headers = ["Data", "d", "c", "Valor", "Vazio", "historico"]
    rows = [row_xml(1, [inline_cell(1, idx, header, 2) for idx, header in enumerate(headers, start=1)])]
    for row_number, tx in enumerate(statement.transactions, start=2):
        rows.append(
            row_xml(
                row_number,
                [
                    inline_cell(row_number, 1, tx.date, 4),
                    inline_cell(row_number, 2, "", 4),
                    inline_cell(row_number, 3, "", 4),
                    number_cell(row_number, 4, tx.amount, 3),
                    inline_cell(row_number, 5, "", 4),
                    inline_cell(row_number, 6, tx.description, 4),
                ],
            )
        )

    if not statement.transactions:
        rows.append(row_xml(2, [inline_cell(2, 1, "Nenhum lancamento encontrado no periodo.", 4)]))

    last_row = max(len(statement.transactions) + 1, 2)
    return sheet_xml(rows, [13, 8, 8, 14, 10, 90], f"A1:F{last_row}")


def write_xlsx(statement: Statement, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as workbook:
        workbook.writestr("[Content_Types].xml", content_types_xml())
        workbook.writestr("_rels/.rels", root_rels_xml())
        workbook.writestr("xl/workbook.xml", workbook_xml())
        workbook.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml())
        workbook.writestr("xl/styles.xml", styles_xml())
        workbook.writestr("xl/worksheets/sheet1.xml", build_transactions_sheet(statement))


def convert_ofx_to_excel(input_path: Path, output_path: Path) -> Statement:
    statement = parse_statement(input_path)
    write_xlsx(statement, output_path)
    return statement


class OfxExcelApp:
    def __init__(self) -> None:
        self.root = Tk()
        self.root.title("OFX para Excel")
        self.root.geometry("760x260")
        self.root.minsize(680, 240)

        self.input_var = StringVar()
        self.output_var = StringVar()
        self.status_var = StringVar(value="Escolha um arquivo OFX e onde salvar o Excel.")

        self._build()

    def _build(self) -> None:
        frame = ttk.Frame(self.root, padding=18)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)

        title = ttk.Label(frame, text="Converter OFX para Excel", font=("Segoe UI", 16, "bold"))
        title.grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 16))

        ttk.Label(frame, text="Arquivo OFX").grid(row=1, column=0, sticky="w", pady=6)
        ttk.Entry(frame, textvariable=self.input_var).grid(row=1, column=1, sticky="ew", padx=8, pady=6)
        ttk.Button(frame, text="Procurar...", command=self.choose_input).grid(row=1, column=2, pady=6)

        ttk.Label(frame, text="Salvar Excel em").grid(row=2, column=0, sticky="w", pady=6)
        ttk.Entry(frame, textvariable=self.output_var).grid(row=2, column=1, sticky="ew", padx=8, pady=6)
        ttk.Button(frame, text="Escolher...", command=self.choose_output).grid(row=2, column=2, pady=6)

        ttk.Button(frame, text="Transformar em Excel", command=self.convert).grid(row=3, column=1, sticky="e", pady=(18, 8))
        ttk.Label(frame, textvariable=self.status_var, foreground="#334155").grid(row=4, column=0, columnspan=3, sticky="w", pady=(12, 0))

    def choose_input(self) -> None:
        path = filedialog.askopenfilename(
            title="Escolha o arquivo OFX",
            filetypes=[("Arquivos OFX", "*.ofx *.OFX"), ("Todos os arquivos", "*.*")],
        )
        if not path:
            return
        self.input_var.set(path)
        if not self.output_var.get():
            self.output_var.set(str(Path(path).with_suffix(".xlsx")))

    def choose_output(self) -> None:
        initial = Path(self.input_var.get()).with_suffix(".xlsx") if self.input_var.get() else Path("extrato.xlsx")
        path = filedialog.asksaveasfilename(
            title="Salvar Excel como",
            initialfile=initial.name,
            defaultextension=".xlsx",
            filetypes=[("Planilha Excel", "*.xlsx")],
        )
        if path:
            self.output_var.set(path)

    def convert(self) -> None:
        input_path = Path(self.input_var.get().strip())
        output_path = Path(self.output_var.get().strip())
        if not input_path.exists():
            messagebox.showerror("Arquivo nao encontrado", "Escolha um arquivo OFX valido.")
            return
        if output_path.suffix.lower() != ".xlsx":
            output_path = output_path.with_suffix(".xlsx")
            self.output_var.set(str(output_path))

        try:
            statement = convert_ofx_to_excel(input_path, output_path)
        except Exception as exc:  # pragma: no cover - GUI feedback path
            messagebox.showerror("Erro na conversao", str(exc))
            self.status_var.set("Nao foi possivel converter o arquivo.")
            return

        self.status_var.set(f"Excel criado com {len(statement.transactions)} lancamento(s): {output_path}")
        messagebox.showinfo("Conversao concluida", f"Excel criado com sucesso:\n{output_path}")

    def run(self) -> None:
        self.root.mainloop()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Converte extrato OFX para Excel.")
    parser.add_argument("inputs", nargs="*", type=Path, help="Arquivo(s) OFX ou pasta(s) com OFX.")
    parser.add_argument("-o", "--output", type=Path, help="Arquivo .xlsx de saida ou pasta de destino.")
    args = parser.parse_args(argv)

    if not args.inputs:
        OfxExcelApp().run()
        return 0

    inputs = collect_inputs(args.inputs)
    if not inputs:
        parser.error("nenhum arquivo OFX encontrado")

    for input_path in inputs:
        if args.output and (len(inputs) > 1 or args.output.is_dir() or args.output.suffix.lower() != ".xlsx"):
            output_path = args.output / f"{input_path.stem}.xlsx"
        elif args.output:
            output_path = args.output
        else:
            output_path = input_path.with_suffix(".xlsx")

        statement = convert_ofx_to_excel(input_path, output_path)
        print(f"Excel criado: {output_path} ({len(statement.transactions)} lancamento(s))")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
