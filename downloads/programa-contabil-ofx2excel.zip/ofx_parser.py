"""OFX parsing helpers for Brazilian bank statement files."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Iterable


@dataclass
class Transaction:
    date: str = ""
    type: str = ""
    amount: Decimal = Decimal("0")
    fitid: str = ""
    checknum: str = ""
    memo: str = ""
    name: str = ""
    refnum: str = ""

    @property
    def description(self) -> str:
        parts = [self.memo, self.name]
        return " - ".join(part for part in parts if part)


@dataclass
class Statement:
    source: Path
    org: str = ""
    fid: str = ""
    bank_id: str = ""
    branch_id: str = ""
    account_id: str = ""
    account_type: str = ""
    currency: str = "BRL"
    start_date: str = ""
    end_date: str = ""
    ledger_balance: Decimal | None = None
    ledger_date: str = ""
    transactions: list[Transaction] = field(default_factory=list)

    @property
    def credits(self) -> Decimal:
        return sum((tx.amount for tx in self.transactions if tx.amount > 0), Decimal("0"))

    @property
    def debits(self) -> Decimal:
        return sum((tx.amount for tx in self.transactions if tx.amount < 0), Decimal("0"))

    @property
    def movement(self) -> Decimal:
        return self.credits + self.debits


def read_ofx(path: Path) -> str:
    raw = path.read_bytes()
    encodings = ["utf-8-sig", "cp1252", "latin-1"]
    for encoding in encodings:
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        text = raw.decode("latin-1", errors="replace")

    if "�" in text:
        repaired = raw.decode("cp1252", errors="replace")
        if repaired.count("�") < text.count("�"):
            text = repaired

    return text.replace("\r\n", "\n").replace("\r", "\n")


def clean_value(value: str) -> str:
    value = html.unescape(value)
    value = re.sub(r"<[^>]+>", "", value)
    value = " ".join(value.split())
    return value.strip()


def tag_value(block: str, tag: str) -> str:
    pattern = re.compile(
        rf"<{tag}\b[^>]*>\s*(.*?)(?=\n?\s*</{tag}>|\n?\s*<[A-Z][A-Z0-9]*\b|$)",
        re.IGNORECASE | re.DOTALL,
    )
    match = pattern.search(block)
    return clean_value(match.group(1)) if match else ""


def all_blocks(text: str, tag: str) -> list[str]:
    return re.findall(rf"<{tag}\b[^>]*>(.*?)(?:</{tag}>)", text, flags=re.IGNORECASE | re.DOTALL)


def section_block(text: str, tag: str) -> str:
    match = re.search(rf"<{tag}\b[^>]*>(.*?)(?:</{tag}>)", text, flags=re.IGNORECASE | re.DOTALL)
    return match.group(1) if match else ""


def parse_decimal(value: str) -> Decimal:
    if not value:
        return Decimal("0")
    value = clean_value(value).replace(" ", "")
    if "," in value and "." in value:
        value = value.replace(".", "").replace(",", ".")
    elif "," in value:
        value = value.replace(",", ".")
    try:
        return Decimal(value)
    except InvalidOperation:
        return Decimal("0")


def parse_ofx_date(value: str) -> str:
    digits = re.match(r"\s*(\d{8,14})", value or "")
    if not digits:
        return clean_value(value)

    raw = digits.group(1)
    fmt = "%Y%m%d%H%M%S" if len(raw) >= 14 else "%Y%m%d"
    try:
        parsed = datetime.strptime(raw[:14] if len(raw) >= 14 else raw[:8], fmt)
    except ValueError:
        return clean_value(value)
    return parsed.strftime("%d/%m/%Y")


def parse_statement(path: Path) -> Statement:
    text = read_ofx(path)
    stmt = Statement(source=path)
    stmt.org = tag_value(text, "ORG")
    stmt.fid = tag_value(text, "FID")
    stmt.currency = tag_value(text, "CURDEF") or "BRL"

    account = section_block(text, "BANKACCTFROM")
    stmt.bank_id = tag_value(account, "BANKID")
    stmt.branch_id = tag_value(account, "BRANCHID")
    stmt.account_id = tag_value(account, "ACCTID")
    stmt.account_type = tag_value(account, "ACCTTYPE")

    banktranlist = section_block(text, "BANKTRANLIST")
    stmt.start_date = parse_ofx_date(tag_value(banktranlist, "DTSTART"))
    stmt.end_date = parse_ofx_date(tag_value(banktranlist, "DTEND"))

    ledger = section_block(text, "LEDGERBAL")
    if ledger:
        stmt.ledger_balance = parse_decimal(tag_value(ledger, "BALAMT"))
        stmt.ledger_date = parse_ofx_date(tag_value(ledger, "DTASOF"))

    for block in all_blocks(text, "STMTTRN"):
        tx = Transaction(
            date=parse_ofx_date(tag_value(block, "DTPOSTED")),
            type=tag_value(block, "TRNTYPE"),
            amount=parse_decimal(tag_value(block, "TRNAMT")),
            fitid=tag_value(block, "FITID"),
            checknum=tag_value(block, "CHECKNUM"),
            memo=tag_value(block, "MEMO"),
            name=tag_value(block, "NAME"),
            refnum=tag_value(block, "REFNUM"),
        )
        stmt.transactions.append(tx)

    return stmt


def collect_inputs(paths: Iterable[Path]) -> list[Path]:
    files: list[Path] = []
    for path in paths:
        if path.is_dir():
            files.extend(sorted([*path.glob("*.ofx"), *path.glob("*.OFX")]))
        else:
            files.append(path)
    return files


def money(value: Decimal | None, currency: str = "BRL") -> str:
    if value is None:
        return "-"
    sign = "-" if value < 0 else ""
    absolute = abs(value).quantize(Decimal("0.01"))
    whole, cents = f"{absolute:.2f}".split(".")
    groups = []
    while whole:
        groups.append(whole[-3:])
        whole = whole[:-3]
    formatted = ".".join(reversed(groups)) + "," + cents
    prefix = "R$ " if currency.upper() == "BRL" else f"{currency} "
    return f"{sign}{prefix}{formatted}"
