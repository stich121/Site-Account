# OFX2EX

Conversor simples de extratos bancarios OFX para Excel e PDF.

Ele foi pensado para OFX brasileiros em formato SGML/XML, incluindo arquivos de Banco do Brasil, Bradesco, Caixa, Santander, Sicoob e Itau. O parser aceita tags sem fechamento, valores com virgula ou ponto decimal, datas com hora/fuso e campos complementares como `NAME` e `REFNUM`.

## Instalar

Para converter em Excel pela interface, nao precisa instalar biblioteca extra.

Para tambem gerar PDF:

```powershell
python -m pip install -r requirements.txt
```

## Abrir a interface OFX para Excel

Com duplo clique no Windows:

```text
OFX2Excel.pyw
```

Esse arquivo abre a janela direto, sem precisar usar PowerShell.

Se preferir abrir pelo terminal:

```powershell
python .\ofx2excel.py
```

Na janela, escolha o arquivo `.ofx`, escolha onde salvar o `.xlsx` e clique em **Transformar em Excel**.

O Excel gerado usa o layout:

```text
Data | d | c | Valor | Vazio | historico
```

## Verificar impostos em XMLs dentro de ZIP

Com duplo clique no Windows:

```text
VerificadorFiscalZIP.pyw
```

Na janela, escolha um arquivo `.zip` com XMLs de notas fiscais, escolha onde salvar o Excel e clique em **Verificar ZIP e gerar Excel**.

O relatório gerado mostra, por XML:

```text
Arquivo | Modelo | Numero | Emissao | CNPJ emissor | Emissor | CNPJ destinatario | Valor nota | ICMS | IPI | PIS | COFINS | ISS | IRRF | INSS | CSLL | Total impostos | Status | Alertas
```

Pelo terminal:

```powershell
python .\fiscal_zip_checker.py ".\notas.zip" -o ".\conferencia_fiscal.xlsx"
```

O app identifica impostos destacados em NF-e, NFC-e, CT-e e tambem tenta reconhecer campos comuns de NFS-e. Quando nenhum imposto com valor maior que zero e encontrado, a linha fica marcada como **Sem imposto destacado** no Excel.

## Converter para Excel pelo terminal

```powershell
python .\ofx2excel.py ".\extrato.ofx" -o ".\extrato.xlsx"
```

## Converter para PDF pelo terminal

```powershell
python .\ofx2pdf.py "G:\Drives compartilhados\A Cotta Colegio Ltda\Contábil\Contabilidade\Extrato bancario\2026\06 2026.ofx"
```

Por padrao, o PDF sera criado ao lado do OFX, com o mesmo nome.
